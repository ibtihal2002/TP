#ifndef HEADER
#define HEADER

#include <stdio.h>
#include <time.h>

int iterative_fibo(int n);
int recursive_fibo(int n);

#endif

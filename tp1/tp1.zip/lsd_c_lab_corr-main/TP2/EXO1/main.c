#include"header.h"
int main()
	{
		t_point *dim = allocateStruct();

	//printf("enter two integers");
	//scanf("%d%d", &(dim.a), &(dim.b));
	printf("%d%d",dim->a,dim->b);
	allocation(t_point dim);


return 0;


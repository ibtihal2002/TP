#ifndef RPN_H
#define RPN_H
//prototype///
#include "stack.h"
int evaluate_RPN(char *tab);

#endif






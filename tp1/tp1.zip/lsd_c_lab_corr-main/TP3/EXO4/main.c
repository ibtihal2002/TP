#include"RPN.h"
int main(int ac,char ** argv)
{
	evaluate_RPN(argv[1]);
	return 0;

}
